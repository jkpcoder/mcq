export * from "./RupeeFontSpan";
