import CardContent, {
  CardContentProps as MuiCardContentProps,
} from "@material-ui/core/CardContent";

export { CardContent };
export type CardContentProps = MuiCardContentProps;
