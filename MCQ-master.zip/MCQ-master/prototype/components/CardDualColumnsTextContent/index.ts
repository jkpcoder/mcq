export * from "./CardDualColumnsTextContent";
