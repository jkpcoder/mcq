import React, { Component } from "react";

// tslint:disable-next-line:no-empty-interface
export interface AdminPanelUsersSummaryContainerProps {}

export class AdminPanelUsersSummaryContainer extends Component<
  AdminPanelUsersSummaryContainerProps
> {
  render() {
    return (
      <>
        <div>Placeholder</div>
      </>
    );
  }
}
