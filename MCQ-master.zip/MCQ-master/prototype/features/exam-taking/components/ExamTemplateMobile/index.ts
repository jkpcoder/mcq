export * from "./ExamTemplateMobile";
