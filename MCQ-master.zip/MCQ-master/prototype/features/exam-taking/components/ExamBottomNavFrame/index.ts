export * from "./ExamBottomNavFrame";
