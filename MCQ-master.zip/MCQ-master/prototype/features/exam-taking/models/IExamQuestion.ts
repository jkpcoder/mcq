// tslint:disable-next-line: interface-name
export interface IExamQuestion {
  status: "answered" | "not-answered" | "marked-for-review" | "not-visited";
}
