import { State } from "../../store";

export const postSignupDialogsShownSelector = (state: State) =>
  state.interfaceTours.postSignupDialogsShown;
