export const colors = {
  green: "#669b64",
};
