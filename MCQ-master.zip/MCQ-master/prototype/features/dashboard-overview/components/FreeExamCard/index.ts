export * from "./FreeExamCard";
