export const componentsEn = {
  components_AttemptButton_Text: "Attempt",
  components_AuthenticationForm_FieldIsRequired: "{} is required.",

  components_FilterButton_MenuCaptionText: "Filter By:",

  components_LogoText_HeroHeader: "JoinUniform",

  components_PageFooter_Text: "Copyright : Eduphilic Consultancy Pvt Ltd 2018",

  components_SelectionSummary_ChangeButtonText: "Change",

  components_ToolbarProfileMenu_LogoutButtonText: "Logout",
};
