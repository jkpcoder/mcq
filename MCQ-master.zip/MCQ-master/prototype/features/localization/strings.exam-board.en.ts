export const examBoardEn = {
  examBoard_SubscriptionCardActions_ReviseButtonTitle: "Revise",
  examBoard_SubscriptionCardActions_AttemptButtonTitle: "Attempt",
  examBoard_SubscriptionCardActions_ExpiredButtonTitle: "Expired",
};
