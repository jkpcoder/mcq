export const pagesEn = {
  pages_admin_Dashboard_CardEntryWiseUsersTitle: "Entry wise Users",

  pages_admin_Dashboard_CardUsersTitle: "Users",
  pages_admin_Dashboard_CardUsersStatTotalUsers: "Total Users",
  pages_admin_Dashboard_CardUsersStatActiveUsers: "Active Users",
  pages_admin_Dashboard_CardUsersStatRegistrationsPastWeek:
    "Registrations Past Week",

  pages_admin_Dashboard_CardMembershipStatusTitle: "Membership Status",
  pages_admin_Dashboard_CardQuestionBankTitle: "Question Bank",

  pages_admin_AdminLogin_HeroTextPrimary:
    "Prepare for INDIAN Defence Examinations",
  pages_admin_AdminLogin_HeroTextSecondary:
    "Some message can be written here to explain about this website",
  pages_admin_AdminLogin_LoginFormTitle: "Admin Login",
};
