export const sessionEn = {
  session_SessionForm_FullNameFieldPlaceholder: "Enter Your Name",
  session_SessionForm_PhoneNumberFieldPlaceholder: "Enter Mobile Number",
  session_SessionForm_PasswordFieldPlaceholder: "Enter Password",
  session_SessionForm_PasswordVerifyFieldPlaceholder: "Enter Password Again",
  session_SessionForm_EmailAddressFieldPlaceholder: "Enter Email Address",
  session_SessionForm_PasswordResetLinkLabel: "Forgot Password?",
  session_SessionForm_FormTitle_UserSignIn: "Login",
  session_SessionForm_FormTitle_UserSignUp: "Signup",
  session_SessionForm_FormTitle_AdminSignIn: "Login",
  session_SessionForm_SubmitButtonLabel: "Submit",
  session_SessionForm_TermsConditionsCheckbox_Label: "Terms & Conditions",
};
