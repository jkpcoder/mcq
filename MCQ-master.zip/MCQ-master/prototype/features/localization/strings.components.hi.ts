import { SecondaryTranslation } from "../../types";
import { componentsEn } from "./strings.components.en";

export const componentsHi: SecondaryTranslation<typeof componentsEn> = {};
