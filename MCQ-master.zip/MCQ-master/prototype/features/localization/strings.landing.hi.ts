import { SecondaryTranslation } from "../../types";
import { landingEn } from "./strings.landing.en";

export const landingHi: SecondaryTranslation<typeof landingEn> = {};
