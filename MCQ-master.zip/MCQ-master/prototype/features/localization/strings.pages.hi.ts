import { SecondaryTranslation } from "../../types";
import { pagesEn } from "./strings.pages.en";

export const pagesHi: SecondaryTranslation<typeof pagesEn> = {};
