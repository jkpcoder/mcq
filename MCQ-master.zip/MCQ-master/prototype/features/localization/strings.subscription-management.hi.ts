import { SecondaryTranslation } from "../../types";
import { subscriptionManagementEn } from "./strings.subscription-management.en";

export const subscriptionManagementHi: SecondaryTranslation<
  typeof subscriptionManagementEn
> = {};
