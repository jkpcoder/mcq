export const dashboardEn = {
  dashboard_OnboardingSubscriptionPage_PayButtonText: "Pay",
};
