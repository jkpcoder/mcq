import { SecondaryTranslation } from "../../types";
import { sessionEn } from "./strings.session.en";

export const sessionHi: SecondaryTranslation<typeof sessionEn> = {};
