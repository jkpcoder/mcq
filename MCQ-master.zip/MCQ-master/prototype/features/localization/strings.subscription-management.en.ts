export const subscriptionManagementEn = {
  subscription_management_QuantitySelectionCardHeader_PricingText:
    "per exam for {} months validity",
};
