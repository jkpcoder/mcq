import { SecondaryTranslation } from "../../types";
import { examBoardEn } from "./strings.exam-board.en";

export const examBoardHi: SecondaryTranslation<typeof examBoardEn> = {};
