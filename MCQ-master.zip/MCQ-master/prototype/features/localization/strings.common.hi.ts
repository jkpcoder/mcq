import { SecondaryTranslation } from "../../types";
import { commonEn } from "./strings.common.en";

export const commonHi: SecondaryTranslation<typeof commonEn> = {
  common_NextButtonText: "आगे",
};
