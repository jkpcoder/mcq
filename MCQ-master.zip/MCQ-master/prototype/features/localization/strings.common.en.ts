export const commonEn = {
  common_NextButtonText: "Next",
};
