export const landingEn = {
  landing_LanguageSelect_Text: "Preferred language :",
  landing_LanguageSelect_ShortText: "Language :",
  landing_LanguageSelect_English: "English",
  landing_LanguageSelect_Hindi: "हिंदी",

  landing_Hero_PrimaryText: "What we are offering mock test",
  landing_Hero_SecondaryText: "Instant result with detail analysis report",

  landing_HeroFooter_TextPrimary: "Free Weekly Mock Test",
  landing_HeroFooter_TextSecondary:
    "Instant result with detail analysis report",
};
