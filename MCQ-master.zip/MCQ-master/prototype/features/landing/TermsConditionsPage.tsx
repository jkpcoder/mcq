import React, { SFC } from "react";

export const TermsConditionsPage: SFC<{}> = () => (
  <div>
    <p>Terms & Conditions page placeholder.</p>
  </div>
);
