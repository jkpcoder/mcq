import React, { SFC } from "react";

export const PasswordResetPage: SFC<{}> = () => (
  <div>
    <p>Password reset page placeholder.</p>
  </div>
);
