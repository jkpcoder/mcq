export * from "./LandingTemplate";
