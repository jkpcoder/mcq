export type IIndexCardColors = {
  entryID: string;
  blockColor: string;
  logoBackgroundColor: string;
  titleColor: string;
  categoryBackgroundColor: string;
  categoryTitleColor: string;
};
