/**
 * Just a placeholder image.
 */
export const storybookPlaceholderImageUrl =
  "https://via.placeholder.com/350x150?text=Placeholder";
