import { storiesOf } from "@storybook/react";
import React from "react";
import { AttemptButton } from ".";

storiesOf("Components V0", module).add("AttemptButton", () => (
  <AttemptButton />
));
