export type DashboardCardColumnType =
  | "dual-line"
  | "image"
  | "profile"
  | "single-line"
  | "switch"
  | "button";
