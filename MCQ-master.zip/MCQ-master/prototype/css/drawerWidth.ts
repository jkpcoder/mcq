/**
 * Width of the navigation drawers.
 */
export const drawerWidth = 240;
